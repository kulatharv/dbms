use("StudentDB");

db.Student.drop();
db.createCollection("Student");

db.Student.insertMany([
  {
    student_id: 1,
    name: "Alice",
    age: 20,
    gender: "Female",
    marks: { math: 85, science: 92, english: 88 }
  },
  {
    student_id: 2,
    name: "Bob",
    age: 19,
    gender: "Male",
    marks: { math: 65, science: 70, english: 72 }
  },
  {
    student_id: 3,
    name: "Charlie",
    age: 21,
    gender: "Male",
    marks: { math: 95, science: 89, english: 78 }
  },
  {
    student_id: 4,
    name: "Diana",
    age: 22,
    gender: "Female",
    marks: { math: 80, science: 75, english: 85 }
  },
  {
    student_id: 5,
    name: "Ethan",
    age: 20,
    gender: "Male",
    marks: { math: 90, science: 95, english: 91 }
  }
]);

// 1. Find all students who are male
db.Student.find({ gender: "Male" });

// 2. Find students who scored more than 90 in math
db.Student.find({ "marks.math": { $gt: 90 } });

// 3. Find students aged 20 and above
db.Student.find({ age: { $gte: 20 } });

// 4. Find students whose English marks are between 80 and 90
db.Student.find({ "marks.english": { $gte: 80, $lte: 90 } });

// 5. Count the number of female students
db.Student.countDocuments({ gender: "Female" });

// 6. Find the student with the highest science score
db.Student.find().sort({ "marks.science": -1 }).limit(1);

// 7. Update Bob’s math score to 75
db.Student.updateOne({ name: "Bob" }, { $set: { "marks.math": 75 } });

// 8. Delete all students who scored below 70 in math
db.Student.deleteMany({ "marks.math": { $lt: 70 } });

// 9. Use aggregation to find the average marks in science for all students
db.Student.aggregate([{ $group: { _id: null, avg_science: { $avg: "$marks.science" } } }]);

// 10. Find the number of students with marks greater than 80 in any subject
db.Student.countDocuments({
  $or: [
    { "marks.math": { $gt: 80 } },
    { "marks.science": { $gt: 80 } },
    { "marks.english": { $gt: 80 } }
  ]
});
