use("LibraryDB");

db.Books.drop();
db.Products.drop();

db.createCollection("Books");
db.createCollection("Products");

db.Books.insertMany([
  { book_id: 1, book_title: "MongoDB Basics", author_name: "John Doe", publish_year: 2015 },
  { book_id: 2, book_title: "Advanced MongoDB", author_name: "John Doe", publish_year: 2018 },
  { book_id: 3, book_title: "Node.js Guide", author_name: "Jane Smith", publish_year: 2016 },
  { book_id: 4, book_title: "Web Development", author_name: "Robert Brown", publish_year: 2014 },
  { book_id: 5, book_title: "Modern Databases", author_name: "Jane Smith", publish_year: 2021 }
]);

db.Products.insertMany([
  { product_id: 1, name: "Keyboard", price: 800 },
  { product_id: 2, name: "Mouse", price: 500 },
  { product_id: 3, name: "Monitor", price: 7000 },
  { product_id: 4, name: "Laptop", price: 55000 },
  { product_id: 5, name: "Pendrive", price: 700 }
]);

//1. Create an index on the price field in Products
db.Products.createIndex({ price: 1 });

// 2. Create a compound index on author_name and publish_year in Books
db.Books.createIndex({ author_name: 1, publish_year: -1 });

// 3. View all indexes created in Books & Products
db.Books.getIndexes();
db.Products.getIndexes();

// 4. Drop the index created on the price field from Products
db.Products.dropIndex({ price: 1 });

// 5. Find total number of books published by each author
db.Books.aggregate([{ $group: { _id: "$author_name", total_books: { $sum: 1 } } }]);

// 6. Calculate average price of all products
db.Products.aggregate([{ $group: { _id: null, average_price: { $avg: "$price" } } }]);

// 7. Find maximum and minimum price in Products
db.Products.aggregate([{ $group: { _id: null, max_price: { $max: "$price" }, min_price: { $min: "$price" } } }]);

// 8. Count books where publish_year > 2015
db.Books.aggregate([{ $match: { publish_year: { $gt: 2015 } } }, { $count: "Books_After_2015" }]);

// 9. Display only book_title and author_name using $project
db.Books.aggregate([{ $project: { _id: 0, book_title: 1, author_name: 1 } }]);

// 10. Sort books by publish_year
db.Books.find().sort({ publish_year: 1 });
