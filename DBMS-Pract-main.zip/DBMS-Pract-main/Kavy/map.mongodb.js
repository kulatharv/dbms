use("LibraryDB1");

db.books.drop();
    
db.createCollection("books");

db.books.insertMany([
  { book_title: "MongoDB Basics", author_name: "John Doe", status: "active", publish_year: 2015 },
  { book_title: "Advanced MongoDB", author_name: "John Doe", status: "active", publish_year: 2018 },
  { book_title: "Node.js Guide", author_name: "Jane Smith", status: "passive", publish_year: 2016 },
  { book_title: "Web Development", author_name: "Robert Brown", status: "active", publish_year: 2014 },
  { book_title: "Modern Databases", author_name: "Jane Smith", status: "active", publish_year: 2021 },
  { book_title: "Database Design", author_name: "Robert Brown", status: "active", publish_year: 2019 }
]);

// Map function – emit only active books grouped by author_name
var mapFunction = function () {
  if (this.status === "active") {
    emit(this.author_name, 1);
  }
};

// Reduce function – count books for each author
var reduceFunction = function (key, values) {
  return Array.sum(values);
};

// Apply mapReduce and store results in a new collection
db.books.mapReduce(
  mapFunction,
  reduceFunction,
  { out: "active_books_count" }
);

// Display results
db.active_books_count.find();
