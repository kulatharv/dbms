use("EmployeeDB");

db.emp1.drop();
db.createCollection("emp1");

db.emp1.insertMany([
  { eno: 101, ename: "Nikhil", address: "Pune", sal: 12000 },
  { eno: 102, ename: "Raj", address: "Mumbai", sal: 8000 },
  { eno: 103, ename: "Neha", address: "Delhi", sal: 18000 },
  { eno: 104, ename: "Manish", address: "Pune", sal: 4000 },
  { eno: 105, ename: "Amit", address: "Nashik", sal: 22000 }
]);

db.emp1.insertOne({
  _id: ObjectId(),
  eno: 106,
  ename: "Nitin",
  address: "Kolhapur",
  sal: 9500
});

db.emp1.find();
db.emp1.find({ sal: { $gt: 5000 } });
db.emp1.find({ sal: { $lt: 15000 } });
db.emp1.find({ sal: { $gt: 10000, $lt: 20000 } });
db.emp1.updateMany({}, { $mul: { sal: 1.10 } });
db.emp1.updateOne({ eno: 102 }, { $mul: { sal: 1.10 } });
db.emp1.deleteMany({ sal: { $lt: 5000 } });
db.emp1.renameCollection("employee1");
db.employee1.find({ ename: { $regex: /^n/i } });
db.employee1.find().sort({ ename: 1 });