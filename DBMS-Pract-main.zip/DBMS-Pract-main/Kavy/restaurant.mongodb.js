use("RestaurantsDB");

db.REST1.drop();
db.createCollection("REST1");

db.REST1.insertMany([
  {
    restaurant_id: 3001,
    name: "Tandoori Flame",
    address: { building: "10A", street: "MG Road", city: "Pune", zipcode: "411001" },
    cuisine_type: "Indian",
    score: 78
  },
  {
    restaurant_id: 3002,
    name: "Pizza Town",
    address: { building: "12B", street: "FC Road", city: "Mumbai", zipcode: "400001" },
    cuisine_type: "Italian",
    score: 88
  },
  {
    restaurant_id: 3003,
    name: "Dragon Palace",
    address: { building: "45C", street: "Link Road", city: "Delhi", zipcode: "110001" },
    cuisine_type: "Chinese",
    score: 82
  },
  {
    restaurant_id: 3004,
    name: "Rajdhani Thali",
    address: { building: "22D", street: "JM Road", city: "Pune", zipcode: "411004" },
    cuisine_type: "Indian",
    score: 92
  },
  {
    restaurant_id: 3005,
    name: "Burger Hub",
    address: { building: "16E", street: "CST Road", city: "Mumbai", zipcode: "400098" },
    cuisine_type: "American",
    score: 70
  }
]);

// 4. Display all documents
db.REST1.find();

// 5. Display restaurant_id, name, city, zipcode (exclude _id)
db.REST1.find({}, { _id: 0, restaurant_id: 1, name: 1, "address.city": 1, "address.zipcode": 1 });

// 6. Find restaurants with score > 80 and < 100
db.REST1.find({ score: { $gt: 80, $lt: 100 } });

// 7. Update score of restaurant_id 3001 to 90
db.REST1.updateOne({ restaurant_id: 3001 }, { $set: { score: 90 } });

// 8. Update cuisine_type of all Indian restaurants to Indian_Zatka
db.REST1.updateMany({ cuisine_type: "Indian" }, { $set: { cuisine_type: "Indian_Zatka" } });

// 9. Delete restaurant with restaurant_id 3003
db.REST1.deleteOne({ restaurant_id: 3003 });

// 10. Delete all restaurants with score < 85
db.REST1.deleteMany({ score: { $lt: 85 } });
